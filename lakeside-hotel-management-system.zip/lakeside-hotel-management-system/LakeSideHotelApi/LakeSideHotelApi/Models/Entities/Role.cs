﻿namespace LakeSideHotelApi.Models.Entities
{
    public enum Role
    {
        Admin,
        User
    }
}
