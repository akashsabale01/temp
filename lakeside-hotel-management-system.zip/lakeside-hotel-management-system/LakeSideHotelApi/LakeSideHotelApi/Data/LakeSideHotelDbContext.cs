﻿using LakeSideHotelApi.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace LakeSideHotelApi.Data
{
    public class LakeSideHotelDbContext : DbContext
    {
        public LakeSideHotelDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}
