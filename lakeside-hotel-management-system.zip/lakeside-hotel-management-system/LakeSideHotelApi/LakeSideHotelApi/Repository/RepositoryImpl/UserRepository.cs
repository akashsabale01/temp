﻿using LakeSideHotelApi.Data;
using LakeSideHotelApi.Models.Entities;

namespace LakeSideHotelApi.Repository.RepositoryImpl
{
    public class UserRepository : IUserRepository
    {

        private LakeSideHotelDbContext _dbContext;

        public IEnumerable<User> GetAllUsers()
        {
            var users = _dbContext.
        }

        public User GetUserById(int id)
        {
            throw new NotImplementedException();
        }

        public void AddUser(User user)
        {
            throw new NotImplementedException();
        }

        public void UpdateUserInfo(User user)
        {
            throw new NotImplementedException();
        }

        public void DeleteUser(int id)
        {
            throw new NotImplementedException();
        }

    }
}
