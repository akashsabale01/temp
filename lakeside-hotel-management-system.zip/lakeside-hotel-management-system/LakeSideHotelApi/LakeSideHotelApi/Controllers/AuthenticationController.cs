﻿namespace LakeSideHotelApi.Controllers
{
    public class AuthenticationController
    {
    }
}
