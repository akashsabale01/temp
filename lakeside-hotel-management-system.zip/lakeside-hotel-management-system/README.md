# lakeside-hotel-management-system


Todays Task..
Akash:

Set up the ASP.NET Web API project.
Install necessary packages like Microsoft.AspNet.WebApi.Cors and Microsoft.AspNet.Identity.
Implement user registration API endpoint.
Implement password hashing and storage.



Gaurav:

Implement user login/logout API endpoints.
Implement token generation and management (if using JWT).
Implement password reset and email confirmation functionalities.




Sahithi:

Define models for users, roles, and permissions.
Implement role-based authorization logic.
Create API endpoints for managing user roles and permissions.




Siddhant:

Secure API endpoints using [Authorize] attribute.
Implement error handling for authentication and authorization failures.
